import { ref, computed } from 'vue'
import type { Language } from '@/types'

export function useLanguages() {
  const languages = ref<Language[]>([])
  const loading = ref(false)
  const selectedDifficulty = ref<'all' | 'beginner' | 'intermediate' | 'advanced'>('all')
  const searchQuery = ref('')

  async function loadLanguages() {
    loading.value = true
    try {
      // En production: await fetch('/api/languages')
      const { PLANETES } = await import('@/data/langages')
      languages.value = PLANETES.flatMap(p => p.langages) as any
    } catch (error) {
      console.error('Erreur de chargement des langages:', error)
    } finally {
      loading.value = false
    }
  }

  const filteredLanguages = computed(() => {
    let result = languages.value

    if (selectedDifficulty.value !== 'all') {
      result = result.filter(lang => lang.difficulty === selectedDifficulty.value)
    }

    if (searchQuery.value) {
      const query = searchQuery.value.toLowerCase()
      result = result.filter(lang => 
        lang.name.toLowerCase().includes(query) ||
        lang.description.toLowerCase().includes(query)
      )
    }

    return result
  })

  const stats = computed(() => ({
    total: languages.value.length,
    completed: languages.value.filter(l => l.progress === 100).length,
    inProgress: languages.value.filter(l => l.progress > 0 && l.progress < 100).length,
    notStarted: languages.value.filter(l => l.progress === 0).length
  }))

  function updateProgress(languageId: string, progress: number) {
    const language = languages.value.find(l => l.id === languageId)
    if (language) {
      language.progress = Math.min(100, Math.max(0, progress))
      language.completedLessons = Math.floor(
        (language.totalLessons * language.progress) / 100
      )
    }
  }

  return {
    languages,
    loading,
    selectedDifficulty,
    searchQuery,
    filteredLanguages,
    stats,
    loadLanguages,
    updateProgress
  }
}
