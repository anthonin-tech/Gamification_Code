export interface Langage {
  nom: string
  sym: string
  couleur: string
  annee: number
  createur: string
  usage: string
  description: string
  popularite: number
  difficulte: number
  liens: string[]
  _posX?: number
  _posY?: number
  _rayon?: number
}

export interface Planete {
  id: string
  nom: string
  couleur: string
  taille: number
  vitesse: number
  orbitePct: number
  description: string
  langages: Langage[]
  _angle?: number
  _posX?: number
  _posY?: number
  _anglesLangages?: number[]
}

export type SceneGalaxie = 'galaxie' | 'solaire' | 'planete'
