import type { Planete } from "@/types/langage"

export const PLANETES: Planete[] = [
    {
        id: "web",
        nom: "Web & Front-end",
        couleur: "#29B6F6",
        taille: 26,
        vitesse: 0.32,
        orbitePct: 0.22,
        description: "Interface, sites, navigateurs",
        langages: [
            {
                nom: "JavaScript",
                sym: "JS",
                couleur: "#F7DC6F",
                annee: 1995,
                createur: "Brendan Eich",
                usage: "Front-end, Node.js, apps web",
                description: "Le langage universel du navigateur...",
                popularite: 99,
                difficulte: 40,
                liens: ["MDN Docs", "Node.js"],
                _posX: 0,
                _posY: 0,
            },
            {
                nom: "HTML",
                sym: "HTML/CSS",
                couleur: "#e5740a",
                annee: 1993,
                createur: "Tim Berners-Lee",
                usage: "Front-end, structure et style",
                description: "HTML et CSS sont les fondations du web. HTML structure le contenu des pages tandis que CSS gère leur apparence visuelle, permettant la création de mises en page responsives et modernes.",
                popularite: 75,
                difficulte: 15,
                liens: ["Angular", "JavaScript"],
                _posX: 0,
                _posY: 0,
            },
            {
                nom: "TS",
                sym: "TypeScript",
                couleur: "#1751da",
                annee: 2012,
                createur: "Anders Hejlsberg",
                usage: "Front-end, back-end, apps scalables",
                description: "TypeScript est un sur-ensemble typé de JavaScript développé par Microsoft. Il ajoute un typage statique optionnel qui améliore la maintenabilité et réduit les bugs dans les grands projets..",
                popularite: 52,
                difficulte: 50,
                liens: ["Vuejs", "JavaScript"],
                _posX: 0,
                _posY: 0,
            },
        ],
    },
    {
        id: "Framework",
        nom: "Framework & Front-end",
        couleur: "#e829f6",
        taille: 26,
        vitesse: 0.32,
        orbitePct: 0.22,
        description: "Interface, sites",
        langages: [
            {
                nom: "TS",
                sym: "TypeScript",
                couleur: "#1751da",
                annee: 2012,
                createur: "Anders Hejlsberg",
                usage: "Front-end, back-end, apps scalables",
                description: "TypeScript est un sur-ensemble typé de JavaScript développé par Microsoft. Il ajoute un typage statique optionnel qui améliore la maintenabilité et réduit les bugs dans les grands projets..",
                popularite: 52,
                difficulte: 50,
                liens: ["Vuejs", "JavaScript"],
                _posX: 0,
                _posY: 0,  
            }
        ],
    },
]

export const TOUS_LES_LANGAGES = PLANETES.flatMap(p => p.langages.map(l => ({ ...l, planete: p }))
)



