<script setup lang="ts">
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'

const totalXP = ref(0)
const streak = ref(3)
const completedLessons = ref<Set<string>>(new Set())

const sidebarOpen = ref(false)
const activeModule = ref(0)
const currentLesson = ref(0)
const currentStep = ref(0)

const quizAnswered = reactive<Record<number, boolean>>({})
const quizSelected = reactive<Record<number, number>>({})
const codeInputs = reactive<Record<number, string>>({})

const playerLevel = computed(() => Math.floor(totalXP.value / 200) + 1)
const levelPercent = computed(() => (totalXP.value % 200) / 2)

const starCanvas = ref<HTMLCanvasElement | null>(null)
let animFrame = 0

function initStars() {
    const c = starCanvas.value
    if (!c) return

    const ctx = c.getContext('2d')

    c.width = window.innerWidth
    c.height = window.innerHeight

    const stars = Array.from({ length: 220}, () => ({
        x: Math.random() * c.width,   
        y: Math.random() * c.height,   
        r: Math.random() * 1.4 + 0.2,  
        o: Math.random(),           
        d: Math.random() > 0.5 ? 1 : -1, 
        s: Math.random() * 0.005 + 0.002 
    }))

    const draw = () => {
        ctx?.clearRect(0, 0, c.width, c.height)

        for (const s of stars) {
            s.o += s.s * s.d
            if (s.o >= 1 || s.o <= 0) s.d *= -1

            ctx?.beginPath()
            ctx?.arc(s.x, s.y, s.r, 0, Math.PI * 2)
            ctx?.fillStyle = `rgba(200,185,255,${s.o})`
            ctx?.fill()
        }

        animFrame = requestAnimationFrame(draw)
    }

    draw()
 
}

onMounted(() => {
    initStars()
    window.addEventListener('resize', initStars)
})

onUnmounted(() => {
  cancelAnimationFrame(animFrame)
  window.removeEventListener('resize', initStars)
})
</script>

<template>
    <main class="course-page">
        <canvas ref="starCanvas" class="star-canvas"></canvas>
        <aside class="sidebar">

        </aside>
        <div class="main-content">

        </div>
    </main>
</template>

<style scoped>
:root {
  --bg:       #060918;        
  --primary:  #7c3aed;         
  --cyan:     #06d6a0;       
  --gold:     #ffd166;        
  --red:      #ff6b6b;        
  --text:     rgba(255,255,255,0.93);
  --muted:    rgba(255,255,255,0.52);
  --mono:     'JetBrains Mono', 'Courier New', monospace;
  --r:        12px;            
}

.course-page {
  display: grid;
  grid-template-columns: 280px 1fr;
  min-height: 100vh;
}

.sidebar {
  height: 100vh;       
  position: sticky;   
  top: 0;
  overflow-y: auto;      
  background: rgba(6,9,24,0.92);
  backdrop-filter: blur(20px); 
}

.star-canvas {
  position: fixed;  
  inset: 0; 
  pointer-events: none; 
  z-index: 0;
}
</style>