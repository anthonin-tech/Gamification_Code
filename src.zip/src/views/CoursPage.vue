<script setup lang="ts">
import type { Langage } from "@/types/langage"
</script>

<template>
    <h1>Apprends le code, explore la galaxie de {{ Langage.nom }}</h1>
</template>