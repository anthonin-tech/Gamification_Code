<script setup lang="ts">
import type { Langage } from "@/types/langage"

const props = defineProps<{
  language: Langage | null
}>()
</script>

<template>
    <h1>Apprends le code, explore la galaxie de {{ language.nom }}</h1>
</template>