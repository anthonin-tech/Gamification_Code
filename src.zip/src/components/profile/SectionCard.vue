<script setup lang="ts">
interface Props {
  iconColor?: string
  title: string
}

defineProps<Props>()
</script>

<template>
  <section class="galaxy-section">
    <div class="galaxy-section__header">
      <div
        v-if="$slots.icon"
        class="galaxy-section__icon"
        :style="iconColor ? { color: iconColor } : {}"
        aria-hidden="true"
      >
        <slot name="icon" />
      </div>
      <h2 class="galaxy-section__title">{{ title }}</h2>
    </div>

    <div class="galaxy-section__body">
      <slot />
    </div>
  </section>
</template>

<style scoped>
.galaxy-section {
  position: relative;
  margin-bottom: 2.8rem;
  padding: 2.2rem;
  border: 1px solid rgba(120, 47, 214, 0.72);
  border-radius: 2rem;
  background: linear-gradient(180deg, rgba(12, 3, 18, 0.9), rgba(3, 4, 16, 0.86));
  box-shadow:
    0 0 0 1px rgba(104, 34, 178, 0.12) inset,
    0 36px 60px rgba(0, 0, 0, 0.28);
  overflow: hidden;
  backdrop-filter: blur(16px);
}

.galaxy-section::before {
  content: '';
  position: absolute;
  inset: -30% auto auto -18%;
  width: 22rem;
  height: 22rem;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(240, 76, 255, 0.18) 0%, transparent 68%);
  filter: blur(12px);
  pointer-events: none;
}

.galaxy-section::after {
  content: '';
  position: absolute;
  right: -6rem;
  top: -10rem;
  width: 32rem;
  height: 32rem;
  border-radius: 50%;
  border: 1px solid rgba(72, 31, 123, 0.26);
  box-shadow:
    0 0 0 140px rgba(32, 13, 53, 0.08),
    0 0 0 280px rgba(26, 14, 47, 0.05);
  opacity: 0.7;
  pointer-events: none;
}

.galaxy-section__header {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.8rem;
}

.galaxy-section__icon {
  width: 2.2rem;
  height: 2.2rem;
  flex: 0 0 auto;
}
.galaxy-section__icon :deep(svg) {
  width: 100%;
  height: 100%;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  fill: none;
}

.galaxy-section__title {
  font-family: 'Sora', sans-serif;
  font-size: clamp(1.7rem, 2.6vw, 2.6rem);
  font-weight: 700;
  letter-spacing: -0.04em;
  margin: 0;
  color: #f0e8ff;
}

.galaxy-section__body {
  position: relative;
  z-index: 1;
}
</style>
