<script setup lang="ts">
import type { Langage } from "@/types/langage"

defineProps<{
    language: Langage | null
}>()

defineEmits<{
    fermer: []
}>()
</script>

<template>
    <Transition name="panneau">
        <aside v-if="language" class="lang-panel">
            <button class="lang-panel__close" @click="$emit('fermer')">×</button>
            <div class="lang-panel__sym" :style="{ color: language.couleur, background: `${language.couleur}22`}">{{ language.sym }}
            </div>
            <h2 class="lang-panel__name">{{ language.nom }}</h2>
            <p class="lang-panel__meta">Crée en {{ language.annee }} • {{ language.createur }}</p>

            <p class="lang-panel__desc">{{ language.description }}</p>

            <div class="lang-panel__section">
                <span class="lang-panel__label">Utilisé pour</span>
                <p class="lang-panel__value">{{ language.usage }}</p>
            </div>

            <div class="lang-panel__section">
                <span class="lang-panel__label">Popularité</span>
                <div class="lang-panel__bar">
                    <div class="lang-panel__bar-fill" :style="{ width: language.popularite + '%', background: language.couleur}" />
                </div>
                <p class="lang-panel__stat">{{ language.popularite }}% des devs l'utilisent</p>
            </div>

            <div v-if="language.liens?.length" class="lang-panel__section">
                <span class="lang-panel__label">Ressources</span>
                <div class="lang-panel__links">
                    <button v-for="lien in language.liens" :key="lien" class="lang-panel__link">{{ lien }}</button>
                </div>
            </div>
        </aside>
    </Transition>
</template>




